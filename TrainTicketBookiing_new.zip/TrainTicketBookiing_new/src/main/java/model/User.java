/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author LENOVO
 */
public class User {
    private int idUser;
    private String nama;
    private String email;
    private String gender;
    private String tanggalLahir;
    private String username;
    private String password;

    public User(int idUser, String nama, String email, String gender, String tanggalLahir, String username, String password) {
        this.idUser = idUser;
        this.nama = nama;
        this.email = email;
        this.gender = gender;
        this.tanggalLahir = tanggalLahir;
        this.username = username;
        this.password = password;
    }
    
    // Konstruktor tanpa idUser
    public User(String nama, String email, String gender, String tanggalLahir, String username, String password) {
        this.nama = nama;
        this.email = email;
        this.gender = gender;
        this.tanggalLahir = tanggalLahir;
        this.username = username;
        this.password = password;
    }
    
    
    public User() {
    }    
    
    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTanggalLahir() {
        return tanggalLahir;
    }

    public void setTanggalLahir(String tanggalLahir) {
        this.tanggalLahir = tanggalLahir;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
}
